package edu.cpt187.Nillas.Program6;
/*
 * Miguel Nillas
 * Start Date: 4/15/2024
 * Assignment 6
 * Purpose: this is the main class that will take user input and give them a read out of thier grade
 */

import java.util.ArrayList;
import java.util.Scanner;

public class GradeCalculator {
	
	public static double PROGRAM_PERCENT = 0.80;

	public static void main(String[] args) 
	{
		ArrayList<ProgramAssignment> programs = new ArrayList<>();
		FinalExam exam;
		Scanner console = new Scanner(System.in);
		char moreGrades = askMorePrograms(console);
		while (moreGrades == 'Y') {
			programs.add(createProgramActivity(console));
			moreGrades = askMorePrograms(console);
		}
		exam = createFinalExam(console);
		displayReport(programs, exam);
	}//end of main class
	
	public static char askMorePrograms(Scanner input)
	{
		System.out.print("Enter a program grade?[Y/N]");
		char moreGrades = input.next().toUpperCase().charAt(0);
		while (moreGrades != 'Y' && moreGrades != 'N') {
			System.out.printf("%c is not a valid response.", moreGrades);
			System.out.print("Enter a program grade?[Y/N]");
			moreGrades = input.next().toUpperCase().charAt(0);
		}
		return moreGrades;
	}

	public static ProgramAssignment createProgramActivity(Scanner input) 
	{
		System.out.print("Enter Documentation grade:");
		int docGrade = input.nextInt();
		System.out.print("Enter Standards grade:");
		int standardsGrade = input.nextInt();
		System.out.print("Enter Correctness grade:");
		int correctnessGrade = input.nextInt();
		//  create and return the program assignment object
		return new ProgramAssignment(docGrade, standardsGrade, correctnessGrade);
	}

	public static FinalExam createFinalExam(Scanner input) {
		FinalExam examGrade;
		System.out.println("Final Exam Grade:");
		System.out.println("Enter number of questions:");
		int docGrade = input.nextInt();
		System.out.print("Enter number missed:");
		int standardsGrade = input.nextInt();
		examGrade = new FinalExam(docGrade, standardsGrade);
		//  create and return the final exam object
		return examGrade;
	}

	private static void displayReport(ArrayList<ProgramAssignment> programs, FinalExam exam)
	{
		double programAverage = calculateProgramAverage(programs);
		displayProgramGrades(programs);
		displayExamInformation(exam);
		displayFinalGrade(programAverage, exam.getScore());
	}
	
	private static void displayFinalGrade(double progAvg, double examAvg) 
	{
		double finalCourseGrade = (progAvg *PROGRAM_PERCENT) + (examAvg * (1-PROGRAM_PERCENT));
		char finalCourseLetterGrade = GradedActivity.getGrade(finalCourseGrade);
		System.out.println("Course Grade:");
		System.out.printf("%-10.2f%c%n", finalCourseGrade, finalCourseLetterGrade);
		
	}
	
	private static void displayProgramGrades(ArrayList<ProgramAssignment> programs) 
	{
		double totalProgramScore = 0;
		System.out.println("Program Grades: ");
		System.out.printf("%-10s%-10s%s%n", "Program", "Score", "Grade");
		int programNumber = 1;
		int size = programs.size();
		for(int i = 0; i < size; i++)
		{
			ProgramAssignment program = programs.get(i);
			System.out.printf("%-10d%-10.2f%c%n", programNumber++, program.getScore(), program.getGrade());
			totalProgramScore = totalProgramScore + program.getScore();
		}
		double averageProgramScore = totalProgramScore/size;
		char programGrade = GradedActivity.getGrade(averageProgramScore);
		System.out.printf("%-10s%-10.2f%c%n%n" , "Average: ", averageProgramScore, programGrade);
	}

	private static void displayExamInformation(FinalExam exam) {
		System.out.println("Final Exam");
		System.out.printf("%-10s%-10s%s%n", "Missed", "Score", "Grade");
		System.out.printf("%-2d%-1s%-7d%-10.2f%c%n%n", exam.getNumMissed(), "/", exam.getNumQuestions(), exam.getScore(), exam.getGrade());
	}
	
	private static double calculateProgramAverage(ArrayList<ProgramAssignment> programs) 
	{
		double totalProgramScore = 0;
		int size = programs.size();
		for(int i = 0; i < size; i++)
		{
			ProgramAssignment program = programs.get(i);
			totalProgramScore = totalProgramScore + program.getScore();
		}
		return totalProgramScore / size;
	}

}//end of main class
