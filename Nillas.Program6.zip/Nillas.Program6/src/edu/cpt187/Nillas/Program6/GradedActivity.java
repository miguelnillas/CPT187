package edu.cpt187.Nillas.Program6;
/**
   A class that holds a grade for a graded activity.
*/
public class GradedActivity
{
	
   private double score;  // Numeric score

   /**
      The setScore method sets the score field.
      @param s The value to store in score.
   */

   protected void setScore(double s)
   {
      score = s;
   }

   /**
      The getScore method returns the score.
      @return The value stored in the score field.
   */

   public double getScore()
   {
      return score;
   }

   /**
      The getGrade method returns a letter grade
      determined from the score field.
      @return The letter grade.
   */

   public char getGrade()
   {
      return getGrade(score);
   }

public static char getGrade(double average) {
      char letterGrade;

      if (average >= 90)
         letterGrade = 'A';
      else if (average >= 80)
         letterGrade = 'B';
      else if (average >= 70)
         letterGrade = 'C';
      else if (average >= 60)
         letterGrade = 'D';
      else
         letterGrade = 'F';

      return letterGrade;
   }
}