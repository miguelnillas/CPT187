package edu.cpt187.Nillas.Program6;
/*
 * Purpose: This class that determines the grade for a program assignment
 */
public class ProgramAssignment extends GradedActivity
{
	private final int DOCUMENTATION_PERCENT = 10;
	private final int STANDARDS_PERCENT = 10;
	private final int CORRECTNESS_PERCENT = 80;
	
	private int documentationScore;
	private int standardsScore;
	private int correctnessScore;
	
	//constructor
	public ProgramAssignment(int docScore, int standScore, int corrScore)
	{
		this.documentationScore = docScore;
		this.standardsScore = standScore;
		this.correctnessScore = corrScore;
		
		double calcScore = calculateScore(); 
		//call
		setScore(calcScore);
	}
	
	public double calculateScore()
	{
		return (DOCUMENTATION_PERCENT*documentationScore / 100) + (STANDARDS_PERCENT*standardsScore/ 100) + (CORRECTNESS_PERCENT*correctnessScore/ 100);
	}
	
	//might not need getters
	
}// end of programAssignment class
