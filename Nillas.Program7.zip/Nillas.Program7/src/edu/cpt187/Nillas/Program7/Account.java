package edu.cpt187.Nillas.Program7;

public class Account 
{
	private double balance;
	private String accountNumber;
	private String accountType;
	
	//Constructor
	public Account(String accountNum, double initBalance, String accountT)
	{
		this.balance = initBalance;
		this.accountNumber = accountNum;
		this.accountType = accountT;
	}
	
	//getters
	
	public double getBalance()
	{
		return balance;
	}
	
	public String getAccountNumber()
	{
		return accountNumber;
	
	}
	
	public String getAccountType()
	{
		return accountType;
	}
	
	
	//important methods 
	
	public boolean deposit(double amount)
	{
		if(amount <= 0)
		{
			return false;
		}else 
		{
			balance = balance + amount;
			return true;
		}
	}
	
	public boolean withdraw(double amount)
	{
		if (amount <= 0 || amount > balance)
		{
			return false;
		}
		else
		{
			balance = balance - amount;
			return true;
		}
		
	}
	
	
	
}//end of class Account
