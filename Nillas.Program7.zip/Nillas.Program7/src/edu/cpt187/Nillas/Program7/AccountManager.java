/*
 * Miguel Nillas
 * Start Date: 4/22/2024
 * Assignment 7
 * Purpose: 
 */

package edu.cpt187.Nillas.Program7;

import java.util.Scanner;

public class AccountManager {
	public static final char LIST_SELECTOR = 'L';
	public static final String LIST_LABEL = "List accounts";
	public static final char MANAGE_SELECTOR = 'M';
	public static final String MANAGE_LABEL = "Manage account";
	public static final char QUIT_SELECTOR = 'Q';
	public static final String QUIT_LABEL = "Quit";

	public static final char DEPOSIT_SELECTOR = 'D';
	public static final String DEPOSIT_LABEL = "Make a Deposit";
	public static final char WITHDRAW_SELECTOR = 'W';
	public static final String WITHDRAW_LABEL = "Make a Withdrawal";
	public static final char RESET_WITHDRAWALS_SELECTOR = 'R';
	public static final String RESET_WITHDRAWALS_LABEL = "Reset Withdrawals";
	
	public static void main(String[] args) {
		Bank bank = new Bank("accountList.txt");
		Scanner keyboard = new Scanner(System.in);
		
		char selection = getValidatedSelection(keyboard);
		while (selection != QUIT_SELECTOR) {
			switch (selection) {
			case LIST_SELECTOR: {
			    listAccounts(bank);
			} break;
			case MANAGE_SELECTOR: {
				manageAccount(keyboard, bank);
			} break;
			}
			selection = getValidatedSelection(keyboard);
		}

		keyboard.close();
		System.out.println("\nDONE");
	}

	private static char getValidatedSelection(Scanner input) {
		char select;
		displayMainMenu();
		select = Character.toUpperCase(input.next().charAt(0));
		while (select != LIST_SELECTOR && select != MANAGE_SELECTOR && select != QUIT_SELECTOR) {
			System.out.printf("Invalid selection: %c%n", select);
			displayMainMenu();
			select = Character.toUpperCase(input.next().charAt(0));
		}
		return select;
	}
	
	private static void displayMainMenu() {
		System.out.println("Please enter your selection from the menu below:");
		System.out.printf("%c) %s%n", LIST_SELECTOR, LIST_LABEL);
		System.out.printf("%c) %s%n", MANAGE_SELECTOR, MANAGE_LABEL);
		System.out.printf("%c) %s%n", QUIT_SELECTOR, QUIT_LABEL);
	}
	
	private static void listAccounts(Bank bank) {
		System.out.printf("%-10s%-10s%10s%n", "Account", "Account", "");
		System.out.printf("%-10s%-10s%10s%n", "Type", "Number", "Balance");
		for (Account acnt : bank.getAllAccounts()) {
			showAccountInformation(acnt);
		}
		System.out.println();
	}
	
	private static void manageAccount(Scanner keyboard, Bank bank) {
		char userSelection;
		Account account = getAccount(keyboard, bank);
		if (account != null) {
			showAccountInformation(account);
			if ((userSelection = getAccountAction(keyboard)) != QUIT_SELECTOR) {
				switch (userSelection) {
				case DEPOSIT_SELECTOR: {
					makeDeposit(keyboard, account);
				} break;
				case WITHDRAW_SELECTOR: {
					makeWithdrawal(keyboard, account);
				} break;
				case RESET_WITHDRAWALS_SELECTOR: {
					resetWithdrawalCount(account);
				} break;
				}
			    showAccountInformation(account);
			}
		}
	}

	private static void showAccountInformation(Account acnt) {
			System.out.printf("%-10s%-10s%10.2f%n", acnt.getAccountType(), acnt.getAccountNumber(), acnt.getBalance());
	}

	private static char getAccountAction(Scanner input) {
		char select;
		displayAccountMenu();
		select = Character.toUpperCase(input.next().charAt(0));
		while (select != RESET_WITHDRAWALS_SELECTOR && select != WITHDRAW_SELECTOR && select != DEPOSIT_SELECTOR && select != QUIT_SELECTOR) {
			System.out.printf("Invalid selection: %c%n", select);
			displayAccountMenu();
			select = Character.toUpperCase(input.next().charAt(0));
		}
		return select;
	}
	
	private static void displayAccountMenu() {
		System.out.printf("%c) %s%n", DEPOSIT_SELECTOR, DEPOSIT_LABEL);
		System.out.printf("%c) %s%n", WITHDRAW_SELECTOR, WITHDRAW_LABEL);
		System.out.printf("%c) %s%n", RESET_WITHDRAWALS_SELECTOR, RESET_WITHDRAWALS_LABEL);
		System.out.printf("%c) %s%n", QUIT_SELECTOR, QUIT_LABEL);
	}

	private static Account getAccount(Scanner keyboard, Bank bank) {
		System.out.printf("Please enter your account Number (\"%s\" to exit): ",QUIT_LABEL);
		String accountNumber = keyboard.next();
		Account acnt = bank.findAccountByNum(accountNumber);
		while (!accountNumber.equalsIgnoreCase(QUIT_LABEL) && acnt == null) {
			System.out.println("That is not a valid account number.");
			System.out.print("Please enter your account Number: ");
			accountNumber = keyboard.next();
			acnt = bank.findAccountByNum(accountNumber);
		}

		return acnt;
	}

	private static void makeDeposit(Scanner input, Account account) {
		double amount = getAmount(input, "Enter the amount for your deposit:");
		if (account.deposit(amount)) {
			System.out.printf("%.2f deposited to account %s.%n", amount, account.getAccountNumber());
		} else {
			System.out.println("Deposit failed!");
		}
	}

	private static void makeWithdrawal(Scanner input, Account account) {
		double amount = getAmount(input, "Enter the amount for your withdrawal:");
		if (account.withdraw(amount)) {
			System.out.printf("%.2f withdrawn from account %s.%n", amount, account.getAccountNumber());
		} else {
			System.out.println("Withdrawal failed!");
		}
	}
	
	private static void resetWithdrawalCount(Account account) {
		if (account instanceof SavingsAccount) {
			((SavingsAccount)account).resetWithdrawalCount();
		}
	}
	
	private static double getAmount(Scanner input, String message) {
		double amt;
		System.out.println(message);
		amt = input.nextDouble();
		input.nextLine(); // clean up buffer
		return amt;
	}
}
