/*
 * Miguel Nillas
 * Start Date: 4/22/2024
 * Assignment 7
 * Purpose: 
 */
package edu.cpt187.Nillas.Program7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
	private ArrayList<Account> accounts = new ArrayList<>();
	
	public Bank(String path) {
		loadAccounts(path);
	}
	
	private void loadAccounts(String dataPath) {
		try {
			Scanner input = new Scanner(new File(dataPath));
			while (input.hasNext())  {
				Account acnt;
				char type = input.next().charAt(0);
				String acntNum = input.next();
				double balance = input.nextDouble();
				// TODO -- write the code that creates the appropriate account
				// and add it to the accounts list
				
				
				if(balance < 0)
				{
					System.err.printf("Invalid balance %.2f", balance);
					//continue;
				}
				
				if(type == 'S')
				{
					acnt = new SavingsAccount(acntNum, balance);
					accounts.add(acnt);
				}
				else if(type == 'C')
				{
					acnt = new CheckingAccount(acntNum, balance);
					accounts.add(acnt);
				}
				else 
				{
					System.err.printf("Invalid Type %c", type);
					//continue;
				}
				
				
				
				
				
			}
			input.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Account> getAllAccounts() {
		return new ArrayList<Account>(accounts);
	}
	
	public Account findAccountByNum(String accntNum) {
		//Account account = null;
		// TODO -- replace the following line with the code to find the account
		for(int i = 0; i < accounts.size(); i++)
		{
			Account account = accounts.get(i);
			if(account.getAccountNumber().equals(accntNum))
			{
				return account;
			}
		}
		return null;
		
	}
}
