package edu.cpt187.Nillas.Program7;

public class CheckingAccount extends Account
{
	private static final double MIN_BALANCE = 100.0;
	private static final double WITHDRAWAL_FEE = 0.25;
	
	//constr
	public CheckingAccount(String accountNum, double initBalance)
	{
		super(accountNum, initBalance, "Checking");
	}
	
	@Override
	public boolean withdraw(double amount)
	{
		if(amount <= 0 || amount > getBalance())
		{
			return false;
		}
		if(getBalance() < MIN_BALANCE)
		{
			amount = amount + WITHDRAWAL_FEE;
		}
		
		return super.withdraw(amount);
	}
	
}//end of checking account
