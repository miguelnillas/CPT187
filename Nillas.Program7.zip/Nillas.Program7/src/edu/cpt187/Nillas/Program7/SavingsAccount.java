package edu.cpt187.Nillas.Program7;

public class SavingsAccount extends Account
{
	private static final int NUM_WITHDRAWALS = 4;
	private int withdrawalCount;
	
	//constr
	public SavingsAccount(String accountNum, double initialBalance)
	{
		super(accountNum, initialBalance, "Savings");
		this.withdrawalCount = 0;
	}
	
	@Override
	public boolean withdraw(double amount)
	{
		if(amount <= 0 || amount > getBalance() || withdrawalCount >= NUM_WITHDRAWALS)
		{
			return false;
		}
		//else {
		withdrawalCount++;
		return super.withdraw(amount);
		
		//}
	}
	
	public void resetWithdrawalCount()
	{
		withdrawalCount = 0;
	}
}// end of savings account class
