//AUTHOR: Miguel Nillas
//COURSE: CPT187
//PURPOSE: This class will handle employees and return desired data
//STARTDATE: 3/23/2024
package edu.cpt187.Nillas.Project3;
import java.util.Random;
import java.util.Scanner;

public class Main {

	
	
	public static void main(String[] args) 
	{
		Random rand = new Random();
		
		String machineID = "123456";
		double downTimeCost = 250.00;
		int days = 365;
		
		WidgetMaker widgetMaker = new WidgetMaker(machineID, downTimeCost, days);
		
		//loading downtime
		for(int i = 1; i <= widgetMaker.getTotalDays(); i++)
		{
				widgetMaker.setDownTimeForDay(i, rand.nextInt(5)); //down for at most 5 hours a day
		}
		
		//daily list report
		System.out.println("DAY     DownTime");
		for(int i = 1; i <= widgetMaker.getTotalDays(); i++)
		{
			System.out.printf("%-14d %-9d\n", i, widgetMaker.getDownTimeForDay(i));
		}
		System.out.println();
		
		//display summary report
		System.out.printf("%-24s %10s\n", "Machine ID", machineID);
		System.out.printf("%-24s %10d\n", "Total Days", widgetMaker.getTotalDays());
		System.out.printf("%-24s %10.2f\n", "Average downtime", widgetMaker.calculateAverageDownTime());
		System.out.printf("%-24s %10.0f\n", "Total downtime", widgetMaker.calculateTotalDownTime());
		System.out.printf("%-24s %10.2f\n", "Average downtime cost", widgetMaker.calculateAverageDownTimeCost());
		System.out.printf("%-24s %10.2f\n", "Total downtime cost", widgetMaker.calculateTotalDownTimeCost());
		System.out.println();
		
		//min and max report
		System.out.printf("%-20s %10s %10s %10s\n", "", "Day", "Hours", "Cost");
		int minIndex = widgetMaker.findMinDayIndex();
		int maxIndex = widgetMaker.findMaxDayIndex();
		System.out.printf("%-20s %10s %10s %10.2f\n", "Min downtime", minIndex, widgetMaker.getDownTimeForDay(minIndex),widgetMaker.getDownTimeForDay(minIndex)*downTimeCost);
		System.out.printf("%-20s %10s %10s %10.2f\n", "Max downtime", maxIndex, widgetMaker.getDownTimeForDay(maxIndex), widgetMaker.getDownTimeForDay(maxIndex)*downTimeCost);
	}

}//end of main
