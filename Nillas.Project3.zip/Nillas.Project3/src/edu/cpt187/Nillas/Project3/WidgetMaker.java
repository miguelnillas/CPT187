//AUTHOR: Miguel Nillas
//COURSE: CPT187
//PURPOSE: This class is a template for all employees at widgetmakers
//STARTDATE: 3/23/2024
package edu.cpt187.Nillas.Project3;

public class WidgetMaker {

	private String ID;
	private double downTimeCost;
	private int[] downTime;
	
	//const
	
	public WidgetMaker(String id, double cost, int period)
	{
		this.ID = id;
		this.downTimeCost = cost;
		this.downTime = new int[period];
		
	}
	
	
	//getters
	
	public String getID()
	{
		return ID;
	}
	
	public int getTotalDays()
	{
		return downTime.length;
	}
	
	public int getDownTimeForDay(int day)
	{
		if( day >= 0  && day < downTime.length)
		{
			return downTime[day];
		}
		else
		{
			return 0;
		}
	}
	
	public double getDownTimeCostForDay(int day)
	{
		return getDownTimeForDay(day) * downTimeCost;
	}
	
	
	//setters
	
	public void setDownTimeForDay(int day, int hours)
	{
		if(day >= 0 && day < downTime.length)
		{
			downTime[day] = hours;
		}
	}
	
	
	
	//return methods, not getters
	
	public double calculateTotalDownTime()
	{
		int total = 0;
		for(int i = 0; i < downTime.length; i++)
		{
			total += downTime[i];
		}
		return total;
	}
	
	public double calculateTotalDownTimeCost()
	{
		double totalCost = 0.0;
		for(int i = 0; i < downTime.length; i++)
		{
			totalCost += downTime[i] * downTimeCost;
		}
		return totalCost;
	}
	
	public double calculateAverageDownTime()
	{
		double totalDownTime = calculateTotalDownTime();
		return totalDownTime/getTotalDays();
	}
	
	public double calculateAverageDownTimeCost()
	{
		double totalCost = calculateTotalDownTimeCost();
		return totalCost/getTotalDays();
	}
	
	
	
	
	public int findMinDayIndex()
	{
		int minIndex = 1;
		int minDownTime = downTime[0];
		for(int i = 0; i < downTime.length; i++)
		{
			if(downTime[i] <= minDownTime)
			{
				minDownTime = downTime[i];
				minIndex = i;
			}
		}
		return minIndex;
	}
	
	
	public int findMaxDayIndex()
	{
		int maxIndex = 1;
		int maxDownTime = downTime[0];
		for(int i = 0; i < downTime.length; i++)
		{
			if(downTime[i] >= maxDownTime)
			{
				maxDownTime = downTime[i];
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	
	
}
