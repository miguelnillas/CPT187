//AUTHOR: Miguel Nillas
//COURSE: CPT187
//PURPOSE: This class is the skeleton for classroom objects
//STARTDATE: 04/03/2024
package edu.cpt187.Nillas.Project4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ClassRoom {

	private String nameOfCourse;
	private String[] names = new String[50];
	private double[] totalGrades = new double[50];
	private int numStudents = 0;
	
	//load grades
	public void loadGrades(String filePath)
	{
		try
		{
			Scanner crScanner = new Scanner(new File(filePath));
			nameOfCourse = crScanner.nextLine();
			
			while(crScanner.hasNextLine()) 
			{
				String name = crScanner.next();
				int[] grades = new int[7];
				for(int i = 0; i < 7; i++)
				{
					grades[i] = crScanner.nextInt();
				}
				addStudent(name, grades);
			}
			crScanner.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("File Not Found Error");
		}
	}
	
	
	//getters
	
	public String getNameByIndex(int index)
	{
		return names[index];
	}
	
	public double getGradeByIndex(int index)
	{
		return totalGrades[index];
	}
	
	public int getNumStudents()
	{
		return numStudents;
	}
	
	//private fields
	
	private void addStudent(String name, int[] grades)
	{
		double total = 0;
		//all grades besides final are worth 10%
		for(int i = 0; i < 6; i++)
		{
			total = total + grades[i];
		}
		//final is worth 40%
		total = grades[6]*4 + total;
		totalGrades[numStudents] = total/100.0;
		names[numStudents] = name;
		numStudents ++;
	}
	
	public int findMaxGrade()
	{
		double max = totalGrades[0];
		int maxIndex = 0;
		
		for(int i = 1; i < numStudents; i++)
		{
			if(totalGrades[i] > max)
			{
				max = totalGrades[i];
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	
	public int findMinGrade()
	{
		double min = totalGrades[0];
		int minIndex = 0;
		
		for(int i = 1; i < numStudents; i++)
		{
			if(totalGrades[i] < min)
			{
				min = totalGrades[i];
				minIndex = i;
			}
		}
		return minIndex;
	}
	
	public int findIndexByName(String name)
	{
		for (int i = 0; i < numStudents; i++)
		{
			if(names[i].equalsIgnoreCase(name))
			{
				return i;
			}
		}
		return -1; 
	}
	
	public double calculateClassAverage()
	{
		double avg = 0;
		for(int i = 0; i < numStudents; i++)
		{
			avg = avg + totalGrades[i];
		}
		return avg / numStudents;
	}
	
}//end of classroom class
