//AUTHOR: Miguel Nillas
//COURSE: CPT187
//PURPOSE: This class handles classroom objects. menu handling
//STARTDATE: 04/03/2024
package edu.cpt187.Nillas.Project4;
import java.util.Scanner;

public class Main {
	private static final String GRADE_FILE = "grades.txt";
	
	public static void main(String[] args) 
	{
		
		ClassRoom classroom = new ClassRoom();
		classroom.loadGrades(GRADE_FILE);
		
		Scanner scanner = new Scanner(System.in);
		
		char selection = ' ';
		
		while (selection != 'Q')
		{
			System.out.println("");
			System.out.println("Menu:");
			System.out.println("1. Highest total grade");
			System.out.println("2. Lowest total grade");
			System.out.println("3. Find Student by name");
			System.out.println("4. Class average");
			System.out.println("5. Show all students");
			System.out.println("Q. Quit");
			System.out.println("");
			System.out.println("Enter your choice: ");
			
			selection = scanner.nextLine().toUpperCase().charAt(0);
			
			if(selection == '1') 
			{
				printStudentWithHighestGrade(classroom);
			}
			else if(selection == '2')
			{
				printStudentWithLowestGrade(classroom);
			}
			else if(selection == '3')
			{
				findStudentByName(classroom, scanner);
			}
			else if(selection == '4')
			{
				printClassAverage(classroom);
			}
			else if(selection == '5')
			{
				printAllStudents(classroom);
			}
			else if(selection == 'Q')
			{
				System.out.println("Quitting the program..");
			}
			else 
			{
				System.out.println("Invalid choice. Try again: ");
			}
		}
		scanner.close();
	}
	
	//highest grade
	private static void printStudentWithHighestGrade(ClassRoom classroom)
	{
		int maxIndex = classroom.findMaxGrade();
		System.out.println("Student with highest grade: ");
		System.out.println(classroom.getNameByIndex(maxIndex) + " " + String.format("%1.f" , classroom.getGradeByIndex(maxIndex)));
	}
	
	private static void printStudentWithLowestGrade(ClassRoom classroom)
	{
		int minIndex = classroom.findMinGrade();
		System.out.println("Student with lowest grade: ");
		System.out.println(classroom.getNameByIndex(minIndex) + " " + String.format("%1.f" , classroom.getGradeByIndex(minIndex)));
	}
	
	private static void findStudentByName(ClassRoom classroom, Scanner scanner)
	{
		System.out.println("Student Search: ");
		String name = scanner.nextLine();
		int index = classroom.findIndexByName(name);
		if(index != -1)
		{
			System.out.println("Found:");
			System.out.println(classroom.getNameByIndex(index)+ " " + String.format("%1.f" , classroom.getGradeByIndex(index)));
		}
		else
		{
			System.out.println("Not Found. Sowwy");
		}
	}
	
	private static void printClassAverage(ClassRoom classroom)
	{
		System.out.println("Class Average : " + String.format("%1.f", classroom.calculateClassAverage()));
	}
	
	private static void printAllStudents(ClassRoom classroom)
	{
		System.out.println("All Studenets");
		for(int i = 0; i < classroom.getNumStudents(); i++)
		{
			System.out.println(classroom.getNameByIndex(i) + String.format("%1.f", classroom.getGradeByIndex(i)));
			
		}
	}
	
}
